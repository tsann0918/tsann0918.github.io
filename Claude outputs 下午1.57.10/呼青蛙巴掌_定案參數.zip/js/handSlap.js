// ===== 鏡頭偵測巴掌：分辨左右手＋揮動速度 =====
// 用 MediaPipe Hand Landmarker（從 CDN 載入，不用安裝）。
// 用法：
//   import { createHandSlap } from './handSlap.js';
//   const cam = await createHandSlap({ video, canvas, onSlap: (e) => game.slapHand(e.hand, e.strength, e.y) });
//   cam.stop();
// 判斷方式：
//   1. 畫面像鏡子（玩家看到的左右＝自己的左右）。
//   2. 右手往左揮（往畫面中間）→ 打青蛙「自己的左臉」；左手往右揮 → 打青蛙右臉。
//   3. 速度＝手掌中心每秒移動幾個畫面寬；超過「最低速度」才算一巴掌，越快力道越大。
//   4. 揮太快時鏡頭可能會暫時找不到手（動態模糊），所以「手突然消失前正在快速往內揮」也算一巴掌。
const VISION = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
const MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

export const HAND_DEFAULTS = {
  minSpeed: 1.6,      // 最低速度（畫面寬／秒）：低於這個不算巴掌
  maxSpeed: 5.0,      // 到這個速度就是最大力道
  cooldown: 0.35,     // 同一隻手兩巴掌之間至少隔幾秒
  needInward: true,   // 只接受往畫面中間揮（右手往左、左手往右）
  swapHands: false,   // 左右手辨識顛倒時打勾
  smoothing: 0.45,    // 速度平滑（0＝不平滑、越大越穩但反應慢）
  lostSlap: true,     // 揮太快手消失時也算一巴掌
  showVideo: true,    // 在 canvas 上畫出鏡頭畫面和手部骨架
};

// 純計算的偵測器（不碰鏡頭，方便測試）：每一格丟進 [{hand, x, y}]（x 已經鏡像，0 左 1 右；y 0 上 1 下）
export function createSlapTracker(P, onSlap) {
  const tracks = {};   // 'left' / 'right'
  function update(hands, t) {
    const seen = new Set();
    for (const h of hands) {
      seen.add(h.hand);
      let tr = tracks[h.hand];
      if (!tr || t - tr.t > 0.35) { tracks[h.hand] = { x: h.x, y: h.y, vx: 0, vy: 0, t, armed: true, lastSlap: -1e9, speed: 0 }; continue; }
      const dt = Math.max(1e-3, t - tr.t);
      const vx = (h.x - tr.x) / dt, vy = (h.y - tr.y) / dt, k = P.smoothing;
      tr.vx = tr.vx * k + vx * (1 - k); tr.vy = tr.vy * k + vy * (1 - k);
      tr.x = h.x; tr.y = h.y; tr.t = t; tr.missing = 0;
      tr.speed = Math.abs(tr.vx); tr.raw = Math.sign(vx) === Math.sign(tr.vx) ? Math.abs(vx) : 0;   // raw：這一格的真實速度，算力道用
      check(h.hand, tr, t, false);
    }
    for (const name of Object.keys(tracks)) {
      const tr = tracks[name];
      if (seen.has(name)) continue;
      // 手不見了：如果前一刻正快速往內揮，就當作打到了
      if (P.lostSlap && !tr.lostChecked) { tr.lostChecked = true; check(name, tr, t, true); }
      if (t - tr.t > 0.35) delete tracks[name];
    }
    for (const name of seen) if (tracks[name]) tracks[name].lostChecked = false;
  }
  function check(hand, tr, t, lost) {
    const inwardDir = hand === 'right' ? -1 : 1;                     // 右手往左（x 變小）、左手往右
    const inward = Math.sign(tr.vx) === inwardDir;
    const sp = Math.abs(tr.vx);
    if (sp < P.minSpeed * 0.5) tr.armed = true;                       // 手慢下來才能再打下一巴掌
    const need = lost ? P.minSpeed * 0.8 : P.minSpeed;
    if (!tr.armed || sp < need || t - tr.lastSlap < P.cooldown) return;
    if (P.needInward && !inward) return;
    tr.armed = false; tr.lastSlap = t;
    const spF = Math.max(sp, tr.raw || 0);                          // 力道用比較即時的速度，才不會被平滑壓低
    const k = Math.max(0, Math.min(1, (spF - P.minSpeed) / Math.max(0.01, P.maxSpeed - P.minSpeed)));
    onSlap({ hand, strength: 0.25 + 0.75 * k, y: Math.max(0, Math.min(1, tr.y)), speed: spF, lost });
  }
  return { update, tracks };
}

export async function createHandSlap({ video, canvas, onSlap, onStatus = () => {}, params = {} }) {
  const P = params;                                   // 直接用傳進來的物件，面板改參數會即時生效
  for (const k in HAND_DEFAULTS) if (!(k in P)) P[k] = HAND_DEFAULTS[k];
  onStatus('載入手部辨識模型…');
  const { FilesetResolver, HandLandmarker } = await import(/* @vite-ignore */ VISION + '/vision_bundle.mjs');
  const fileset = await FilesetResolver.forVisionTasks(VISION + '/wasm');
  let landmarker;
  try {
    landmarker = await HandLandmarker.createFromOptions(fileset, { baseOptions: { modelAssetPath: MODEL, delegate: 'GPU' }, runningMode: 'VIDEO', numHands: 2 });
  } catch {
    landmarker = await HandLandmarker.createFromOptions(fileset, { baseOptions: { modelAssetPath: MODEL, delegate: 'CPU' }, runningMode: 'VIDEO', numHands: 2 });
  }
  onStatus('開啟鏡頭…');
  const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: 'user' }, audio: false });
  video.srcObject = stream; video.muted = true; video.playsInline = true; await video.play();
  onStatus('偵測中：揮手打青蛙！');

  const last = { hands: [] };
  const tracker = createSlapTracker(P, (e) => { flash[e.hand] = 1; onSlap && onSlap(e); });
  const flash = { left: 0, right: 0 };
  const ctx = canvas && canvas.getContext('2d');
  let lastVideoTime = -1, raf = 0, stopped = false;

  function loop() {
    if (stopped) return;
    raf = requestAnimationFrame(loop);
    if (video.readyState < 2 || video.currentTime === lastVideoTime) return;
    lastVideoTime = video.currentTime;
    const t = performance.now() / 1000;
    const res = landmarker.detectForVideo(video, performance.now());
    const hands = [];
    (res.landmarks || []).forEach((lm, i) => {
      const label = res.handednesses?.[i]?.[0]?.categoryName || 'Right';
      // MediaPipe 假設畫面是鏡像的；鏡頭原始畫面沒鏡像，所以標籤要對調
      let hand = label === 'Left' ? 'right' : 'left';
      if (P.swapHands) hand = hand === 'right' ? 'left' : 'right';
      const ids = [0, 5, 9, 13, 17];                                  // 手腕＋四個指根＝手掌中心
      let x = 0, y = 0; ids.forEach((j) => { x += lm[j].x; y += lm[j].y; }); x /= ids.length; y /= ids.length;
      hands.push({ hand, x: 1 - x, y, lm });
    });
    last.hands = hands;
    tracker.update(hands, t);
    draw();
  }
  function draw() {
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    ctx.save(); ctx.clearRect(0, 0, W, H);
    if (P.showVideo) { ctx.translate(W, 0); ctx.scale(-1, 1); ctx.globalAlpha = 0.85; ctx.drawImage(video, 0, 0, W, H); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; }
    for (const h of last.hands) {
      const col = h.hand === 'right' ? '#c8fa6e' : '#ff8fc0';
      ctx.fillStyle = col;
      for (const p of h.lm) { ctx.beginPath(); ctx.arc((1 - p.x) * W, p.y * H, 2.2, 0, 7); ctx.fill(); }
      const tr = tracker.tracks[h.hand];
      ctx.font = 'bold 13px system-ui'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#0008'; ctx.lineWidth = 3;
      const label = (h.hand === 'right' ? '右手' : '左手') + (tr ? ` ${tr.speed.toFixed(1)}` : '');
      ctx.strokeText(label, h.x * W - 18, h.y * H - 14); ctx.fillText(label, h.x * W - 18, h.y * H - 14);
    }
    // 速度條＋門檻線
    ['left', 'right'].forEach((name, i) => {
      const tr = tracker.tracks[name], sp = tr ? tr.speed : 0, x0 = i ? W - 14 : 6, hh = H - 12;
      ctx.fillStyle = '#0005'; ctx.fillRect(x0, 6, 8, hh);
      ctx.fillStyle = flash[name] > 0 ? '#fff' : (name === 'right' ? '#c8fa6e' : '#ff8fc0');
      const k = Math.min(1, sp / (P.maxSpeed * 1.1)); ctx.fillRect(x0, 6 + hh * (1 - k), 8, hh * k);
      const th = 6 + hh * (1 - P.minSpeed / (P.maxSpeed * 1.1)); ctx.fillStyle = '#fff'; ctx.fillRect(x0 - 2, th, 12, 2);
      flash[name] = Math.max(0, flash[name] - 0.08);
    });
    ctx.restore();
  }
  loop();
  return {
    params: P,
    get hands() { return last.hands; },
    stop() { stopped = true; cancelAnimationFrame(raf); stream.getTracks().forEach((t) => t.stop()); landmarker.close(); if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height); },
  };
}
